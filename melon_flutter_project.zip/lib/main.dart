import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() => runApp(const MelonApp());

const melonGreen = Color(0xFF19E6A2);
const deepBackground = Color(0xFF05090D);
const panel = Color(0xFF101820);
const muted = Color(0xFF9AA9B7);

class MelonApp extends StatelessWidget {
  const MelonApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'melon',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: deepBackground,
        colorScheme: const ColorScheme.dark(
          primary: melonGreen,
          secondary: melonGreen,
          surface: panel,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: panel,
          hintStyle: const TextStyle(color: muted),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const MelonShell(),
    );
  }
}

class MelonShell extends StatefulWidget {
  const MelonShell({super.key});
  @override
  State<MelonShell> createState() => _MelonShellState();
}

class _MelonShellState extends State<MelonShell> {
  int tab = 0;
  final Set<String> saved = {};
  final List<Post> posts = [
    Post('Learn', 'Tech Skills for the Future', 'Build practical digital skills one step at a time.', Icons.code),
    Post('Explore', 'Places to Visit Around Uganda', 'Discover new places, ideas and experiences.', Icons.landscape),
    Post('Tips', 'Productivity Made Simple', 'Small habits can make your day more focused.', Icons.edit_note),
  ];
  final List<Post> uploads = [];

  void toggleSaved(String title) {
    setState(() => saved.contains(title) ? saved.remove(title) : saved.add(title));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(posts: posts, saved: saved, onSave: toggleSaved,
          onExplore: () => setState(() => tab = 1),
          onLearn: () => setState(() => tab = 2),
          onConnect: () => setState(() => tab = 3),
          onUpload: _pickUpload),
      ExplorePage(posts: [...uploads, ...posts], saved: saved, onSave: toggleSaved),
      LearnPage(posts: posts, saved: saved, onSave: toggleSaved),
      ConnectPage(),
      SavedPage(posts: [...uploads, ...posts], saved: saved, onSave: toggleSaved),
      ProfilePage(onUpload: _pickUpload, uploadCount: uploads.length),
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab > 4 ? 4 : tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        backgroundColor: const Color(0xFF080E13),
        indicatorColor: melonGreen.withOpacity(.15),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: melonGreen), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore, color: melonGreen), label: 'Explore'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book, color: melonGreen), label: 'Learn'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble, color: melonGreen), label: 'Connect'),
          NavigationDestination(icon: Icon(Icons.bookmark_border), selectedIcon: Icon(Icons.bookmark, color: melonGreen), label: 'Saved'),
        ],
      ),
      floatingActionButton: tab == 0 || tab == 1 ? FloatingActionButton(
        backgroundColor: melonGreen, foregroundColor: Colors.black,
        onPressed: _pickUpload, child: const Icon(Icons.add),
      ) : null,
    );
  }

  Future<void> _pickUpload() async {
    final picker = ImagePicker();
    final picked = await showModalBottomSheet<XFile?>(
      context: context,
      backgroundColor: panel,
      builder: (ctx) => SafeArea(child: Wrap(children: [
        ListTile(leading: const Icon(Icons.photo_library, color: melonGreen), title: const Text('Choose photo or video'), onTap: () async {
          final f = await picker.pickMedia(); if (ctx.mounted) Navigator.pop(ctx, f);
        }),
        ListTile(leading: const Icon(Icons.camera_alt, color: melonGreen), title: const Text('Take a photo'), onTap: () async {
          final f = await picker.pickImage(source: ImageSource.camera); if (ctx.mounted) Navigator.pop(ctx, f);
        }),
      ])),
    );
    if (picked == null || !mounted) return;
    setState(() => uploads.insert(0, Post('Your upload', picked.name, 'Added locally on this device.', Icons.perm_media, localPath: picked.path)));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Added to your local feed. Online sharing needs a backend.')));
  }
}

class Post {
  final String category, title, description;
  final IconData icon;
  final String? localPath;
  Post(this.category, this.title, this.description, this.icon, {this.localPath});
}

class PageHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget? trailing;
  const PageHeader(this.title, this.subtitle, {super.key, this.trailing});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Icon(Icons.watermelon, color: melonGreen, size: 27), const SizedBox(width: 8),
          const Text('melon', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800, letterSpacing: -.8))]),
        const SizedBox(height: 18),
        Text(title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        Text(subtitle, style: const TextStyle(color: muted, fontSize: 14)),
      ])),
      if (trailing != null) trailing!,
    ]),
  );
}

class HomePage extends StatelessWidget {
  final List<Post> posts;
  final Set<String> saved;
  final ValueChanged<String> onSave;
  final VoidCallback onExplore, onLearn, onConnect, onUpload;
  const HomePage({super.key, required this.posts, required this.saved, required this.onSave,
    required this.onExplore, required this.onLearn, required this.onConnect, required this.onUpload});
  @override
  Widget build(BuildContext context) => ListView(children: [
    PageHeader('Good morning, Edrine', 'Small steps today, big results tomorrow.',
      trailing: IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsPage())), icon: const Icon(Icons.notifications_none))),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 18), child: TextField(
      readOnly: true, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SearchPage(posts: posts))),
      decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search on Melon...', suffixIcon: Icon(Icons.tune, color: melonGreen)),
    )),
    const SizedBox(height: 20),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 18), child: Row(children: [
      _QuickAction(Icons.explore, 'Explore', onExplore), _QuickAction(Icons.menu_book, 'Learn', onLearn),
      _QuickAction(Icons.people_alt_outlined, 'Connect', onConnect), _QuickAction(Icons.add_photo_alternate_outlined, 'Upload', onUpload),
    ])),
    const SizedBox(height: 24),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 18), child: Container(
      padding: const EdgeInsets.all(22), decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
          colors: [Color(0xFF173A39), Color(0xFF111B27), Color(0xFF080D12)]),
        border: Border.all(color: const Color(0xFF29414B))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('FEATURED', style: TextStyle(color: melonGreen, letterSpacing: 2, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const Text('Better Ideas,\\nBrighter Days', style: TextStyle(fontSize: 28, height: 1.12, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Explore, learn and grow with Melon.', style: TextStyle(color: muted)),
        const SizedBox(height: 18),
        FilledButton.icon(onPressed: onExplore, icon: const Icon(Icons.arrow_forward), label: const Text('Get Started'),
          style: FilledButton.styleFrom(backgroundColor: melonGreen, foregroundColor: Colors.black)),
      ]),
    )),
    const SizedBox(height: 24),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: Row(children: [
      const Icon(Icons.local_fire_department, color: melonGreen), const SizedBox(width: 8),
      const Expanded(child: Text('Trending for you', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
      TextButton(onPressed: onExplore, child: const Text('See all')),
    ])),
    ...posts.map((p) => PostTile(post: p, isSaved: saved.contains(p.title), onSave: () => onSave(p.title))),
    const SizedBox(height: 12),
  ]);
}

class _QuickAction extends StatelessWidget {
  final IconData icon; final String label; final VoidCallback onTap;
  const _QuickAction(this.icon, this.label, this.onTap);
  @override
  Widget build(BuildContext context) => Expanded(child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18),
    child: Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Column(children: [
      Container(width: 58, height: 58, decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)),
        child: Icon(icon, color: melonGreen, size: 27)),
      const SizedBox(height: 8), Text(label, style: const TextStyle(fontSize: 12)),
    ]))));
}

class PostTile extends StatelessWidget {
  final Post post; final bool isSaved; final VoidCallback onSave;
  const PostTile({super.key, required this.post, required this.isSaved, required this.onSave});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.fromLTRB(18, 5, 18, 9), padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFF1B2B35))),
    child: Row(children: [
      Container(width: 58, height: 58, decoration: BoxDecoration(color: const Color(0xFF12332D), borderRadius: BorderRadius.circular(16)),
        child: Icon(post.icon, color: melonGreen, size: 29)),
      const SizedBox(width: 13),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(post.category.toUpperCase(), style: const TextStyle(color: melonGreen, fontSize: 10, letterSpacing: 1.2, fontWeight: FontWeight.bold)),
        const SizedBox(height: 5), Text(post.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 4), Text(post.description, style: const TextStyle(color: muted, fontSize: 12)),
      ])),
      IconButton(onPressed: onSave, icon: Icon(isSaved ? Icons.bookmark : Icons.bookmark_border, color: isSaved ? melonGreen : muted)),
    ]),
  );
}

class ExplorePage extends StatefulWidget {
  final List<Post> posts; final Set<String> saved; final ValueChanged<String> onSave;
  const ExplorePage({super.key, required this.posts, required this.saved, required this.onSave});
  @override State<ExplorePage> createState() => _ExplorePageState();
}
class _ExplorePageState extends State<ExplorePage> {
  String query = '';
  @override
  Widget build(BuildContext context) {
    final filtered = widget.posts.where((p) => ('${p.title} ${p.description} ${p.category}').toLowerCase().contains(query.toLowerCase())).toList();
    return Column(children: [
      const PageHeader('Explore', 'Find ideas, people and useful content.'),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 18), child: TextField(
        onChanged: (v) => setState(() => query = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search Melon'),
      )),
      Expanded(child: ListView(children: filtered.map((p) => PostTile(post: p, isSaved: widget.saved.contains(p.title), onSave: () => widget.onSave(p.title))).toList())),
    ]);
  }
}

class LearnPage extends StatelessWidget {
  final List<Post> posts; final Set<String> saved; final ValueChanged<String> onSave;
  const LearnPage({super.key, required this.posts, required this.saved, required this.onSave});
  @override
  Widget build(BuildContext context) => ListView(children: [
    const PageHeader('Learn', 'Practical ideas to grow your skills.'),
    Container(margin: const EdgeInsets.all(18), padding: const EdgeInsets.all(20), decoration: BoxDecoration(
      color: panel, borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFF20343D))),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(Icons.auto_stories, color: melonGreen, size: 34), SizedBox(height: 12),
        Text('Your learning space', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        SizedBox(height: 8), Text('Explore bite-sized learning content and save useful topics for later.', style: TextStyle(color: muted)),
      ])),
    ...posts.where((p) => p.category == 'Learn' || p.category == 'Tips').map((p) => PostTile(post: p, isSaved: saved.contains(p.title), onSave: () => onSave(p.title))),
  ]);
}

class ConnectPage extends StatelessWidget {
  ConnectPage({super.key});
  final List<String> chats = const ['Melon Community', 'Learning Partners', 'Ideas & Projects'];
  @override
  Widget build(BuildContext context) => ListView(children: [
    const PageHeader('Connect', 'Conversations start with people.'),
    ...chats.map((name) => ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      leading: const CircleAvatar(backgroundColor: Color(0xFF12332D), child: Icon(Icons.people, color: melonGreen)),
      title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: const Text('Start a local demo conversation', style: TextStyle(color: muted)),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(title: name))),
    )),
    Container(margin: const EdgeInsets.all(18), padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
      child: const Text('Demo mode: messages are stored only while this screen is open. Real messaging between users requires a backend.', style: TextStyle(color: muted))),
  ]);
}

class ChatPage extends StatefulWidget {
  final String title; const ChatPage({super.key, required this.title});
  @override State<ChatPage> createState() => _ChatPageState();
}
class _ChatPageState extends State<ChatPage> {
  final controller = TextEditingController();
  final messages = <String>[];
  @override void dispose() { controller.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.title)),
    body: Column(children: [
      Expanded(child: messages.isEmpty ? const Center(child: Text('Say hello to start this demo chat.', style: TextStyle(color: muted))) :
        ListView(padding: const EdgeInsets.all(16), children: messages.map((m) => Align(alignment: Alignment.centerRight, child: Container(
          margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: const Color(0xFF123A30), borderRadius: BorderRadius.circular(16)), child: Text(m)))).toList()),
      SafeArea(child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
        Expanded(child: TextField(controller: controller, decoration: const InputDecoration(hintText: 'Write a message...'))),
        IconButton(onPressed: () { if (controller.text.trim().isNotEmpty) { setState(() => messages.add(controller.text.trim())); controller.clear(); } },
          icon: const Icon(Icons.send, color: melonGreen)),
      ]))),
    ]),
  );
}

class SavedPage extends StatelessWidget {
  final List<Post> posts; final Set<String> saved; final ValueChanged<String> onSave;
  const SavedPage({super.key, required this.posts, required this.saved, required this.onSave});
  @override
  Widget build(BuildContext context) {
    final items = posts.where((p) => saved.contains(p.title)).toList();
    return ListView(children: [
      const PageHeader('Saved', 'Keep useful things close.'),
      if (items.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Column(children: [
        Icon(Icons.bookmark_border, size: 48, color: muted), SizedBox(height: 12),
        Text('Nothing saved yet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        SizedBox(height: 6), Text('Use the bookmark icon on content to save it here.', textAlign: TextAlign.center, style: TextStyle(color: muted)),
      ])),
      ...items.map((p) => PostTile(post: p, isSaved: true, onSave: () => onSave(p.title))),
    ]);
  }
}

class ProfilePage extends StatelessWidget {
  final VoidCallback onUpload; final int uploadCount;
  const ProfilePage({super.key, required this.onUpload, required this.uploadCount});
  @override
  Widget build(BuildContext context) => ListView(children: [
    const PageHeader('Your profile', 'Manage your Melon space.'),
    const SizedBox(height: 12),
    const Center(child: CircleAvatar(radius: 42, backgroundColor: Color(0xFF12332D), child: Icon(Icons.person, size: 45, color: melonGreen))),
    const SizedBox(height: 12),
    const Center(child: Text('Edrine', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold))),
    const Center(child: Text('Local demo profile', style: TextStyle(color: muted))),
    const SizedBox(height: 20),
    ListTile(leading: const Icon(Icons.perm_media, color: melonGreen), title: const Text('My uploads'), subtitle: Text('$uploadCount item(s) on this device'), onTap: onUpload),
    const ListTile(leading: Icon(Icons.lock_outline, color: melonGreen), title: Text('Account and privacy'), subtitle: Text('Sign-in and account services not configured')),
    const ListTile(leading: Icon(Icons.settings_outlined, color: melonGreen), title: Text('Settings')),
    const ListTile(leading: Icon(Icons.info_outline, color: melonGreen), title: Text('About Melon'), subtitle: Text('Cross-platform app starter')),
  ]);
}

class SearchPage extends StatefulWidget {
  final List<Post> posts; const SearchPage({super.key, required this.posts});
  @override State<SearchPage> createState() => _SearchPageState();
}
class _SearchPageState extends State<SearchPage> {
  String q = '';
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Search Melon')),
    body: Column(children: [
      Padding(padding: const EdgeInsets.all(16), child: TextField(autofocus: true, onChanged: (v) => setState(() => q = v), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search ideas, topics...'))),
      Expanded(child: ListView(children: widget.posts.where((p) => ('${p.title} ${p.description} ${p.category}').toLowerCase().contains(q.toLowerCase()))
        .map((p) => ListTile(leading: Icon(p.icon, color: melonGreen), title: Text(p.title), subtitle: Text(p.category))).toList())),
    ]),
  );
}

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Notifications')),
    body: const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('You are all caught up. Notifications will appear here when a notification service is connected.', textAlign: TextAlign.center, style: TextStyle(color: muted)))),
  );
}
